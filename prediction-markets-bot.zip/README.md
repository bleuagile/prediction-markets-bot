# 🤖 Prediction Markets AI Autopilot — Backend 24/7

Corre análisis automático cada 5 minutos, gratis, via GitHub Actions.
El frontend en Netlify lee los resultados sin necesidad de tener el browser abierto.

---

## ⚙️ Setup (10 minutos)

### Paso 1 — Crear repo en GitHub

1. Ve a github.com → New repository
2. Nombre: `prediction-markets-bot`
3. Visibilidad: **Public** (necesario para que Netlify lea el JSON sin auth)
4. Crear el repo

### Paso 2 — Subir estos archivos al repo

```
prediction-markets-bot/
├── .github/
│   └── workflows/
│       └── analyze.yml      ← el cron job
├── public/
│   └── latest-analysis.json ← se crea automáticamente
├── analyze.js               ← el script principal
├── package.json
└── README.md
```

### Paso 3 — Agregar tu Anthropic API Key como Secret

1. En tu repo → Settings → Secrets and variables → Actions
2. Click "New repository secret"
3. Name: `ANTHROPIC_API_KEY`
4. Value: tu API key de Anthropic (sk-ant-...)
5. Save

### Paso 4 — Activar GitHub Actions

1. En tu repo → pestaña "Actions"
2. Si aparece un aviso, click "I understand my workflows, go ahead and enable them"
3. El cron se activa solo. También puedes correrlo manualmente: Actions → analyze → Run workflow

### Paso 5 — Conectar con tu app de Netlify

En tu app de Netlify (famous-jalebi-54eede.netlify.app), agrega este fetch
para leer el análisis en tiempo real:

```javascript
const ANALYSIS_URL = 'https://raw.githubusercontent.com/TU_USUARIO/prediction-markets-bot/main/public/latest-analysis.json';

// Fetch cada 5 minutos
setInterval(async () => {
  const res = await fetch(ANALYSIS_URL + '?t=' + Date.now()); // cache-bust
  const data = await res.json();
  console.log('Último análisis:', data.timestamp);
  console.log('Sentiment:', data.analysis.sentiment);
  // Actualizar tu UI aquí
}, 5 * 60 * 1000);
```

---

## 📊 Estructura del JSON generado

```json
{
  "timestamp": "2025-04-01T14:30:00.000Z",
  "analysis": {
    "summary": "Resumen ejecutivo...",
    "sentiment": "bullish",
    "confidence": 0.78,
    "polymarket_picks": [...],
    "kalshi_picks": [...],
    "risk_level": "medium",
    "next_key_events": [...]
  },
  "markets": {
    "polymarket": [...],
    "kalshi": [...]
  },
  "meta": {
    "source": "github-actions-cron",
    "nextRunIn": "5 minutos"
  }
}
```

---

## 💰 Costo total: $0

| Servicio | Plan | Límite | Uso |
|----------|------|--------|-----|
| GitHub Actions | Free | 2,000 min/mes | ~720 min/mes (5min cada vez) |
| Netlify | Free | Frontend hosting | Ya lo tienes |
| Anthropic API | Pay-per-use | — | ~$0.001 por análisis con Haiku |

> Con Claude Haiku, 288 análisis diarios (cada 5 min) cuestan aprox. **$0.30/mes**.

---

## ✅ Verificar que funciona

Después de hacer push, ve a:
`https://raw.githubusercontent.com/TU_USUARIO/prediction-markets-bot/main/public/latest-analysis.json`

Si ves el JSON, todo está corriendo.
